# Project summary

**Title:** Azure SQL Database with Failover Group and Private Endpoint

**Problem:** Keep a database-backed application available during a regional SQL failure without exposing SQL to the public internet and without editing application configuration after failover.

**Core Azure services:** Azure SQL Database, SQL Failover Groups, Private Link/Private Endpoints, Azure Private DNS, Azure Virtual Network, Azure VM.

**Key demo:** Insert a record -> trigger planned failover -> refresh -> insert another record using the same application listener.

**Expected result:** The connection endpoint in the application remains `<failover-group>.database.windows.net` while the current primary SQL server changes.

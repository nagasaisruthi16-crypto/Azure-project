# 5-minute hackathon demo

## 1. Problem

“Applications often depend on one database endpoint. If the regional database becomes unavailable, the application configuration can become the bottleneck.”

## 2. Architecture

Show:

- East US: primary SQL
- West US: geo-secondary SQL
- Private endpoint in each region
- Shared private DNS zone
- App VM in the primary VNet
- Failover-group read/write listener

## 3. Security

Show that:

- Public network access on both SQL servers is disabled.
- SQL traffic uses Private Link.
- The app resolves SQL through private DNS.

## 4. Live application

Open the Flask dashboard.

Create:

`Hackathon Judge -> Failover Test`

Show the current primary server.

## 5. Trigger failover

```bash
az sql failover-group set-primary \
  --name <fg> \
  --resource-group <rg> \
  --server <secondary>
```

Say:

“We are changing the primary database role. The application still uses exactly the same listener.”

## 6. Prove no application change

Refresh the dashboard.

The current primary should now be the secondary server.

Create:

`Hackathon Judge -> Post-Failover Test`

The app connection endpoint has not changed.

## 7. DNS insight

```bash
nslookup <fg>.database.windows.net
nslookup <primary>.database.windows.net
nslookup <secondary>.database.windows.net
```

Explain that DNS is part of the disaster-recovery design.

## Final pitch

“We combined Azure SQL geo-redundancy with Private Link and private DNS. The database is not publicly exposed, the application uses one stable failover-group listener, and a planned regional failover can be demonstrated without changing application code or its database endpoint.”

# Azure SQL Database with Failover Group and Private Endpoint

Hackathon-ready implementation of:

- Highly available Azure SQL Database across two Azure regions
- Azure SQL Failover Group with a stable read/write listener
- Private Endpoints + Private DNS
- Public network access disabled on both SQL logical servers
- Demo Flask application that keeps the same database connection endpoint during failover

## Architecture

```text
                         Internet
                            |
                         SSH only
                            |
                    +----------------+
                    | Demo VM        |
                    | Ubuntu + Flask |
                    +-------+--------+
                            |
                     VNet / Private DNS
                            |
                 +----------+-----------+
                 |                      |
        Private Endpoint        Private Endpoint
          Primary SQL             Secondary SQL
                 |                      |
          East US SQL DB  <==geo==>  West US SQL DB
                 \________ Failover Group ________/
                         |
              fg-name.database.windows.net
                    read/write listener
```

The application connects only to the failover-group listener. It does not contain the primary server name, so a planned failover does not require an application configuration change.

## Prerequisites

- Azure subscription
- Azure CLI
- Bash / WSL / Azure Cloud Shell
- Permission to create resource groups, networking, SQL, and VM resources

## 1. Deploy

```bash
az login
export SQL_ADMIN_PASSWORD='Use-A-Strong-Password-Here!'
bash infra/deploy.sh
```

The script creates:

- Resource group
- Primary VNet/subnets in East US
- Secondary VNet/subnet in West US
- Primary and secondary Azure SQL logical servers
- One demo database
- SQL failover group
- Private endpoints for both SQL servers
- Shared Private DNS zone
- Demo Ubuntu VM

The deployment script prints the VM public IP, SSH command, and failover-group listener.

> For a real production deployment, use Key Vault/managed identity rather than putting a SQL password in shell environment variables.

## 2. Start the demo app

SSH to the VM using the printed command:

```bash
ssh azureuser@<VM_PUBLIC_IP>
```

Then:

```bash
cd ~/azure-sql-demo
set -a; source .env; set +a
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Initialize the database:

```bash
sqlcmd -S "$SQL_LISTENER" -d "$DB_NAME" \
  -U sqladmin -P '<SQL_ADMIN_PASSWORD>' \
  -N -C -i schema.sql
```

Start the app:

```bash
python3 app.py
```

From your laptop, create an SSH tunnel:

```bash
ssh -L 5000:127.0.0.1:5000 azureuser@<VM_PUBLIC_IP>
```

Open `http://127.0.0.1:5000`.

## 3. Test normal operation

The dashboard shows:

- Database connectivity
- Current primary server
- Failover-group listener
- DNS resolution
- Insert/read test

Create a demo order and refresh.

## 4. Test failover

From Azure CLI:

```bash
az sql failover-group set-primary \
  --name <FAILOVER_GROUP_NAME> \
  --resource-group <RESOURCE_GROUP_NAME> \
  --server <SECONDARY_SERVER_NAME>
```

After failover:

1. Refresh the dashboard.
2. The application still uses the same listener:
   `<failover-group>.database.windows.net`
3. The current primary server changes.
4. No application code or connection string is changed.
5. Private DNS/private endpoints continue to provide private SQL connectivity.

To move the primary role back, run the same command with the original primary as the target.

## 5. DNS bottleneck demo

Inside the VM:

```bash
nslookup <PRIMARY_SERVER_NAME>.database.windows.net
nslookup <SECONDARY_SERVER_NAME>.database.windows.net
nslookup <FAILOVER_GROUP_NAME>.database.windows.net
```

Also:

```bash
getent hosts <FAILOVER_GROUP_NAME>.database.windows.net
```

The important point is that the application uses the listener, not a hard-coded regional SQL server.

## 6. Security story

- SQL logical servers have public network access disabled.
- SQL traffic reaches the database through Private Link.
- Private DNS resolves SQL names for the VNet.
- The failover group supplies a stable application endpoint.
- Credentials are not stored in the Flask source.

## Cost note

Costs depend on the SQL tier, VM size, storage, region, and runtime. Delete the resource group after the hackathon if you no longer need it:

```bash
bash infra/destroy.sh
```

CREATE TABLE demo_orders (
    id INT IDENTITY(1,1) PRIMARY KEY,
    customer NVARCHAR(100) NOT NULL,
    item NVARCHAR(100) NOT NULL,
    created_at DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);

INSERT INTO demo_orders(customer, item)
VALUES
('Hackathon Judge', 'Availability Test'),
('Demo User', 'Failover Test');

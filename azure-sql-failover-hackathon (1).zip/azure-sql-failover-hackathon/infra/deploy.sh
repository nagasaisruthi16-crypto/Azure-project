#!/usr/bin/env bash
set -euo pipefail

RG="${RG:-rg-azsql-ha-demo}"
PRIMARY_REGION="${PRIMARY_REGION:-eastus}"
SECONDARY_REGION="${SECONDARY_REGION:-westus}"

SUFFIX="${SUFFIX:-$(openssl rand -hex 3)}"
PRIMARY_SERVER="${PRIMARY_SERVER:-sqlpri${SUFFIX}}"
SECONDARY_SERVER="${SECONDARY_SERVER:-sqlsec${SUFFIX}}"
DB_NAME="${DB_NAME:-hackathon_db}"
FAILOVER_GROUP="${FAILOVER_GROUP:-fg${SUFFIX}}"
VNET_PRIMARY="${VNET_PRIMARY:-vnet-sql-primary}"
VNET_SECONDARY="${VNET_SECONDARY:-vnet-sql-secondary}"
VM_NAME="${VM_NAME:-demo-vm}"
ADMIN_USER="${ADMIN_USER:-azureuser}"

: "${SQL_ADMIN_PASSWORD:?Set SQL_ADMIN_PASSWORD before running}"

echo "Creating resource group and networking..."

az group create -n "$RG" -l "$PRIMARY_REGION" >/dev/null

az network vnet create -g "$RG" -n "$VNET_PRIMARY" -l "$PRIMARY_REGION" \
  --address-prefix 10.10.0.0/16 \
  --subnet-name app-subnet --subnet-prefix 10.10.1.0/24 >/dev/null

az network vnet subnet create -g "$RG" --vnet-name "$VNET_PRIMARY" \
  -n pe-subnet --address-prefixes 10.10.2.0/24 \
  --disable-private-endpoint-network-policies true >/dev/null

az network vnet create -g "$RG" -n "$VNET_SECONDARY" -l "$SECONDARY_REGION" \
  --address-prefix 10.20.0.0/16 \
  --subnet-name pe-subnet --subnet-prefix 10.20.2.0/24 \
  --disable-private-endpoint-network-policies true >/dev/null

echo "Creating shared private DNS zone..."

az network private-dns zone create -g "$RG" \
  -n privatelink.database.windows.net >/dev/null

az network private-dns link vnet create -g "$RG" \
  -z privatelink.database.windows.net \
  -n link-primary -v "$VNET_PRIMARY" -e false >/dev/null

az network private-dns link vnet create -g "$RG" \
  -z privatelink.database.windows.net \
  -n link-secondary -v "$VNET_SECONDARY" -e false >/dev/null

echo "Creating Azure SQL servers..."

az sql server create -g "$RG" -l "$PRIMARY_REGION" \
  -n "$PRIMARY_SERVER" -u sqladmin -p "$SQL_ADMIN_PASSWORD" >/dev/null

az sql server create -g "$RG" -l "$SECONDARY_REGION" \
  -n "$SECONDARY_SERVER" -u sqladmin -p "$SQL_ADMIN_PASSWORD" >/dev/null

az sql db create -g "$RG" -s "$PRIMARY_SERVER" -n "$DB_NAME" \
  --service-objective Basic >/dev/null

echo "Creating private endpoints..."

PRIMARY_ID="$(az sql server show -g "$RG" -n "$PRIMARY_SERVER" --query id -o tsv)"
SECONDARY_ID="$(az sql server show -g "$RG" -n "$SECONDARY_SERVER" --query id -o tsv)"

az network private-endpoint create -g "$RG" \
  -n pe-sql-primary -l "$PRIMARY_REGION" \
  --vnet-name "$VNET_PRIMARY" --subnet pe-subnet \
  --private-connection-resource-id "$PRIMARY_ID" \
  --group-id sqlServer --connection-name pe-sql-primary-connection >/dev/null

az network private-endpoint dns-zone-group create -g "$RG" \
  --endpoint-name pe-sql-primary -n default \
  --private-dns-zone privatelink.database.windows.net \
  --zone-name sql >/dev/null

az network private-endpoint create -g "$RG" \
  -n pe-sql-secondary -l "$SECONDARY_REGION" \
  --vnet-name "$VNET_SECONDARY" --subnet pe-subnet \
  --private-connection-resource-id "$SECONDARY_ID" \
  --group-id sqlServer --connection-name pe-sql-secondary-connection >/dev/null

az network private-endpoint dns-zone-group create -g "$RG" \
  --endpoint-name pe-sql-secondary -n default \
  --private-dns-zone privatelink.database.windows.net \
  --zone-name sql >/dev/null

echo "Disabling public SQL access..."

az sql server update -g "$RG" -n "$PRIMARY_SERVER" \
  --public-network-access Disabled >/dev/null

az sql server update -g "$RG" -n "$SECONDARY_SERVER" \
  --public-network-access Disabled >/dev/null

echo "Creating failover group..."

DB_ID="$(az sql db show -g "$RG" -s "$PRIMARY_SERVER" -n "$DB_NAME" --query id -o tsv)"

az sql failover-group create \
  -g "$RG" -s "$PRIMARY_SERVER" -n "$FAILOVER_GROUP" \
  --partner-server "$SECONDARY_SERVER" \
  --failover-policy Automatic --grace-period 1 \
  --add-db "$DB_ID" >/dev/null

echo "Creating demo VM..."

az vm create -g "$RG" -n "$VM_NAME" \
  --location "$PRIMARY_REGION" --image Ubuntu2204 \
  --size Standard_B1s \
  --vnet-name "$VNET_PRIMARY" --subnet app-subnet \
  --admin-username "$ADMIN_USER" --generate-ssh-keys \
  --public-ip-sku Standard >/dev/null

VM_IP="$(az vm show -d -g "$RG" -n "$VM_NAME" --query publicIps -o tsv)"

echo "Installing ODBC and Python dependencies..."

az vm run-command invoke -g "$RG" -n "$VM_NAME" \
  --command-id RunShellScript \
  --scripts 'sudo apt-get update && sudo ACCEPT_EULA=Y apt-get install -y python3-pip python3-venv unixodbc unixodbc-dev curl gnupg2 ca-certificates' \
            'curl -sSL https://packages.microsoft.com/keys/microsoft.asc | sudo gpg --dearmor -o /usr/share/keyrings/microsoft-prod.gpg' \
            'curl -sSL https://packages.microsoft.com/config/ubuntu/22.04/prod.list | sudo tee /etc/apt/sources.list.d/mssql-release.list >/dev/null' \
            'sudo apt-get update && sudo ACCEPT_EULA=Y apt-get install -y msodbcsql18' >/dev/null

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
LISTENER="${FAILOVER_GROUP}.database.windows.net"
CONN="Driver={ODBC Driver 18 for SQL Server};Server=tcp:${LISTENER},1433;Database=${DB_NAME};Uid=sqladmin;Pwd=${SQL_ADMIN_PASSWORD};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=5;"

APP_B64="$(base64 -w 0 "$ROOT_DIR/app/app.py")"
REQ_B64="$(base64 -w 0 "$ROOT_DIR/app/requirements.txt")"
SCHEMA_B64="$(base64 -w 0 "$ROOT_DIR/sql/schema.sql")"
ENV_CONTENT="SQL_LISTENER=$LISTENER
DB_NAME=$DB_NAME
SQL_CONNECTION_STRING=$CONN"
ENV_B64="$(printf '%s' "$ENV_CONTENT" | base64 -w 0)"

az vm run-command invoke -g "$RG" -n "$VM_NAME" \
  --command-id RunShellScript \
  --scripts "mkdir -p /home/$ADMIN_USER/azure-sql-demo && echo $APP_B64 | base64 -d > /home/$ADMIN_USER/azure-sql-demo/app.py && echo $REQ_B64 | base64 -d > /home/$ADMIN_USER/azure-sql-demo/requirements.txt && echo $SCHEMA_B64 | base64 -d > /home/$ADMIN_USER/azure-sql-demo/schema.sql && echo $ENV_B64 | base64 -d > /home/$ADMIN_USER/azure-sql-demo/.env && chown -R $ADMIN_USER:$ADMIN_USER /home/$ADMIN_USER/azure-sql-demo && chmod 600 /home/$ADMIN_USER/azure-sql-demo/.env" >/dev/null

echo
echo "=============================================="
echo "DEPLOYMENT COMPLETE"
echo "=============================================="
echo "Resource group: $RG"
echo "Primary SQL:    $PRIMARY_SERVER"
echo "Secondary SQL:  $SECONDARY_SERVER"
echo "Database:       $DB_NAME"
echo "Failover group: $FAILOVER_GROUP"
echo "Listener:       $LISTENER"
echo "VM public IP:   $VM_IP"
echo
echo "SSH:"
echo "ssh $ADMIN_USER@$VM_IP"
echo
echo "On the VM:"
echo "  cd ~/azure-sql-demo"
echo "  set -a; source .env; set +a"
echo "  python3 -m venv .venv"
echo "  source .venv/bin/activate"
echo "  pip install -r requirements.txt"
echo "  sqlcmd -S \"$LISTENER\" -d \"$DB_NAME\" -U sqladmin -P '<SQL_ADMIN_PASSWORD>' -N -C -i schema.sql"
echo "  python3 app.py"
echo
echo "Local browser tunnel:"
echo "ssh -L 5000:127.0.0.1:5000 $ADMIN_USER@$VM_IP"

#!/usr/bin/env bash
set -euo pipefail
RG="${RG:-rg-azsql-ha-demo}"
read -r -p "Delete resource group $RG and ALL resources inside it? Type DELETE: " confirm
if [[ "$confirm" != "DELETE" ]]; then
  echo "Cancelled."
  exit 1
fi
az group delete -n "$RG" --yes --no-wait
echo "Deletion started."

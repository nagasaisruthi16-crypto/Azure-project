import os
import socket
from datetime import datetime, timezone

import pyodbc
from flask import Flask, jsonify, render_template_string, request

app = Flask(__name__)

CONNECTION_STRING = os.environ.get("SQL_CONNECTION_STRING", "")

HTML = r"""
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Azure SQL HA Demo</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; background:#f5f7fb; color:#172033; }
    .card { background:white; padding:22px; margin:15px 0; border-radius:12px; box-shadow:0 2px 10px #0001; }
    .ok { color:green; font-weight:bold; }
    .bad { color:#b00020; font-weight:bold; }
    button { padding:10px 16px; border:0; border-radius:8px; cursor:pointer; }
    input { padding:10px; margin:4px; }
    code { background:#eef1f6; padding:3px 6px; border-radius:5px; }
  </style>
</head>
<body>
<h1>Azure SQL Failover + Private Endpoint Demo</h1>

<div class="card">
  <h2>Live status</h2>
  <div id="status">Loading...</div>
</div>

<div class="card">
  <h2>Demo transaction</h2>
  <form id="orderForm">
    <input id="customer" placeholder="Customer name" required>
    <input id="item" placeholder="Item" required>
    <button type="submit">Create demo order</button>
  </form>
  <p id="message"></p>
</div>

<div class="card">
  <h2>Recent orders</h2>
  <button onclick="loadOrders()">Refresh</button>
  <pre id="orders">Loading...</pre>
</div>

<script>
async function loadStatus() {
  const r = await fetch('/api/status');
  const x = await r.json();
  document.getElementById('status').innerHTML =
    `<p class="${x.ok ? 'ok':'bad'}">${x.ok ? 'CONNECTED' : 'NOT CONNECTED'}</p>
     <p>Listener: <code>${x.listener}</code></p>
     <p>Resolved IP(s): <code>${x.resolved_ips}</code></p>
     <p>Current primary reported by SQL: <code>${x.server_name || 'n/a'}</code></p>
     <p>UTC: ${x.time}</p>
     <p>${x.message}</p>`;
}
async function loadOrders() {
  const r = await fetch('/api/orders');
  document.getElementById('orders').textContent =
    JSON.stringify(await r.json(), null, 2);
}
document.getElementById('orderForm').onsubmit = async (e) => {
  e.preventDefault();
  const body = {customer: customer.value, item: item.value};
  const r = await fetch('/api/orders', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify(body)
  });
  document.getElementById('message').textContent =
    JSON.stringify(await r.json());
  loadOrders(); loadStatus();
};
loadStatus(); loadOrders();
setInterval(loadStatus, 10000);
</script>
</body>
</html>
"""

def connect():
    if not CONNECTION_STRING:
        raise RuntimeError("SQL_CONNECTION_STRING is not set")
    return pyodbc.connect(CONNECTION_STRING, timeout=5)

@app.get("/")
def index():
    return render_template_string(HTML)

@app.get("/api/status")
def status():
    listener = os.environ.get("SQL_LISTENER", "not-set")
    try:
        ips = socket.gethostbyname_ex(listener)[2]
    except Exception as e:
        ips = [f"DNS error: {e}"]

    try:
        with connect() as cn:
            cur = cn.cursor()
            cur.execute("""
                SELECT @@SERVERNAME AS server_name,
                       DB_NAME() AS database_name,
                       SYSUTCDATETIME() AS sql_time
            """)
            row = cur.fetchone()
            return jsonify({
                "ok": True,
                "listener": listener,
                "resolved_ips": ips,
                "server_name": str(row.server_name),
                "database": str(row.database_name),
                "sql_time": str(row.sql_time),
                "time": datetime.now(timezone.utc).isoformat(),
                "message": "Private SQL connectivity is working."
            })
    except Exception as e:
        return jsonify({
            "ok": False,
            "listener": listener,
            "resolved_ips": ips,
            "server_name": None,
            "time": datetime.now(timezone.utc).isoformat(),
            "message": str(e)
        }), 503

@app.get("/api/orders")
def get_orders():
    try:
        with connect() as cn:
            cur = cn.cursor()
            cur.execute("""
                SELECT TOP 20 id, customer, item, created_at
                FROM demo_orders
                ORDER BY id DESC
            """)
            rows = [
                {"id": r.id, "customer": r.customer,
                 "item": r.item, "created_at": str(r.created_at)}
                for r in cur.fetchall()
            ]
            return jsonify(rows)
    except Exception as e:
        return jsonify({"error": str(e)}), 503

@app.post("/api/orders")
def create_order():
    data = request.get_json(force=True)
    customer = data.get("customer", "").strip()
    item = data.get("item", "").strip()
    if not customer or not item:
        return jsonify({"error": "customer and item are required"}), 400

    try:
        with connect() as cn:
            cur = cn.cursor()
            cur.execute(
                "INSERT INTO demo_orders(customer, item) VALUES (?, ?)",
                customer, item
            )
            cn.commit()
        return jsonify({"ok": True, "message": "Order stored in Azure SQL."})
    except Exception as e:
        return jsonify({"error": str(e)}), 503

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)

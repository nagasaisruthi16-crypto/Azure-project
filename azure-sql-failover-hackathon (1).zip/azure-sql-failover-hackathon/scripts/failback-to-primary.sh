#!/usr/bin/env bash
set -euo pipefail
RG="${RG:-rg-azsql-ha-demo}"
PRIMARY_SERVER="${PRIMARY_SERVER:?Set PRIMARY_SERVER}"
SECONDARY_SERVER="${SECONDARY_SERVER:?Set SECONDARY_SERVER}"
FAILOVER_GROUP="${FAILOVER_GROUP:?Set FAILOVER_GROUP}"

az sql failover-group set-primary \
  --name "$FAILOVER_GROUP" \
  --resource-group "$RG" \
  --server "$PRIMARY_SERVER" \
  --partner-server "$SECONDARY_SERVER"

echo "Failback requested."
